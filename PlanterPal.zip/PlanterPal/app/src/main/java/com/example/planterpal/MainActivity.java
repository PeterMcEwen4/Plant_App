package com.example.planterpal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String url = "https://thingspeak.com/channels/1334745/feeds?api_key=LV2U9BL20EDXF8RO";
        //String url = "https://thingspeak.com/channels/935349/feeds";
        final TextView textView = findViewById(R.id.textView);
        RequestQueue queue = Volley.newRequestQueue((this));

        Button btnChecker = (Button) findViewById(R.id.btnChecker);
        btnChecker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String[] valueHolder = new String[2];
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                String recentValues = response.substring(response.length() - 54);
                                valueHolder[0] = "Date and Time: " + recentValues.substring(0,10) + ", "
                                        + recentValues.substring(11,19);
                                valueHolder[1] = "hydration level: " +
                                        recentValues.substring((recentValues.length() - 7), (recentValues.length() - 4));
                                textView.setText(valueHolder[0] +
                                        ",   " + valueHolder[1]);
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        textView.setText("Oops! Something went wrong.");
                    }
                });

                queue.add(stringRequest);
            }
        });
    }
}